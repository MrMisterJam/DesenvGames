﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControllerX : MonoBehaviour
{
    public GameObject dogPrefab;
    private int spawnDogInterval = 150;
    private int timeSinceSpawn = 0;

    // Update is called once per frame
    void Update()
    {
        // On spacebar press, send dog
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (timeSinceSpawn >= spawnDogInterval) {
                Instantiate(dogPrefab, transform.position, dogPrefab.transform.rotation);
                timeSinceSpawn = 0;
            }
            
        }
        timeSinceSpawn++;
    }
}
